export EASEL_VERSION=h4.0dev 
export EASEL_DATE="Apr 2015"
export EASEL_COPYRIGHT="Copyright (C) 2015 Howard Hughes Medical Institute."
export EASEL_LICENSE="Freely distributed under the open source BSD license."

