#ifndef p7HMMDWRKR_INCLUDED
#define p7HMMDWRKR_INCLUDED

#include "esl_getopts.h"

extern void worker_process(ESL_GETOPTS *go);

#endif /*p7HMMDWRKR_INCLUDED*/
/*****************************************************************
 * @LICENSE@
 * 
 * SVN $Id$
 * SVN $URL$
 *****************************************************************/
