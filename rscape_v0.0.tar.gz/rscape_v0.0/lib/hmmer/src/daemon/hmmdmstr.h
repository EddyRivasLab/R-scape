#ifndef p7HMMDMSTR_INCLUDED
#define p7HMMDMSTR_INCLUDED

#include "esl_getopts.h"

extern void master_process(ESL_GETOPTS *go);

#endif /*p7HMMDMSTR_INCLUDED*/
/*****************************************************************
 * @LICENSE@
 * 
 * SVN $Id$
 * SVN $URL$
 *****************************************************************/
