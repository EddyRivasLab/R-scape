Please see R2R-manual.pdf in this directory
