% NLOPT_GD_MLSL: Multi-level single-linkage (MLSL), random (global, derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_GD_MLSL
  val = 21;
